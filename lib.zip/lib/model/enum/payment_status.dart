enum PaymentStatus { pending, paid, overdue }
