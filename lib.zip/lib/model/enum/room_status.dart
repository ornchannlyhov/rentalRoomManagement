enum RoomStatus { available, occupied }
