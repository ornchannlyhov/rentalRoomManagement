enum Gender{
  male,female,other
}